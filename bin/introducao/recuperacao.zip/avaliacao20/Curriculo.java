package introducao.avaliacao20;

import java.util.ArrayList;

public class Curriculo {
    private Pessoa pessoa;
    private ArrayList<Formacao> listaFormacoes = new ArrayList<>();
    private ArrayList<ExperienciaProfissional> listaExperienciasProfissionais = new ArrayList<>();

    public ArrayList<ExperienciaProfissional> getListaExperienciasProfissionais() {
        return listaExperienciasProfissionais;
    }
    public void setListaExperienciasProfissionais(ArrayList<ExperienciaProfissional> listaExperienciasProfissionais) {
        this.listaExperienciasProfissionais = listaExperienciasProfissionais;
    }

    public ArrayList<Formacao> getListaFormacoes() {
        return listaFormacoes;
    }
    public void setListaFormacoes(ArrayList<Formacao> listaFormacoes) {
        this.listaFormacoes = listaFormacoes;
    }

    public Pessoa getPessoa() {
        return pessoa;
    }
    public void setPessoa(Pessoa pessoa) {
        this.pessoa = pessoa;
    }

    public String gerarCurriculo() {
        StringBuilder dados = new StringBuilder();
    
        dados.append("Nome: " + getPessoa().getNome());
        dados.append("Data de nascimento: " + getPessoa().getDataNascimento());

        
        
        for(int i = 0; i < listaFormacoes.size(); i++){
            var umaForm = listaFormacoes.get(i);
            dados.append("Formação: " + umaForm.getNome());
            dados.append("Ano de conclusão: " + umaForm.getAnoConclusao());
        }
        
        return dados.toString();
    }

    public String contarNumExperienciasProfissionais() {

        StringBuilder experiencias = new StringBuilder();
        for(int i = 0; i < listaExperienciasProfissionais.size(); i++){
            var umaExp = listaExperienciasProfissionais.get(i).getNome();
            experiencias.append(umaExp);
        }
        
        return experiencias.toString(); 
    } 

}
